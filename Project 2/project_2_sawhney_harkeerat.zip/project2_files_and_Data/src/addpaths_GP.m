% add necessary paths for the Partitioning Toolbox

addpath ../datasets/
addpath ../datasets/Mesh_generation/
addpath ../datasets/2d_3d_meshes
addpath ../external/
addpath Visualization/
