function data = degree_centrality()
    
end

