% Question 6.3
A = A_construct(10);
disp(A);
spy(A);

